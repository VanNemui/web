<?php
include "header.php";
include "slide.php";

?>


<div class="admin-content-right">
            <div class="admin-content-right-category">
                <h1>Thêm danh mục</h1>
                <form action="" method="POST">
                    <input type="text" placeholder="Nhập tên danh mục">
                    <button type="submit">Thêm</button>
                </form>
            </div>
        </div>
    </section>

    
</body>

</html>